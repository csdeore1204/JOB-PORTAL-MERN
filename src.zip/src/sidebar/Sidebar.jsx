import React from 'react'
import Location from './Location' 
import Salary from 'c:/Users/Admin/OneDrive/Desktop/MERN Job Portal/job-portal-client/src/sidebar/Salary'
import JobPostingData from 'c:/Users/Admin/OneDrive/Desktop/MERN Job Portal/job-portal-client/src/sidebar/JobPostingData'
import WorkExperience from 'c:/Users/Admin/OneDrive/Desktop/MERN Job Portal/job-portal-client/src/sidebar/WorkExperience'
import EmploymentType from 'c:/Users/Admin/OneDrive/Desktop/MERN Job Portal/job-portal-client/src/sidebar/EmploymentType'



           
const Sidebar = ({handleChange, handleClick}) => {
  return (
    <div className='space-y-5'>
        <h3 className='text-lg font-bold mb-2'>Filters</h3>

        <Location handleChange={handleChange}/>
        <Salary handleChange={handleChange} handleClick={handleClick}/>
        <JobPostingData handleChange={handleChange}/>
        <WorkExperience handleChange={handleChange}/>
        <EmploymentType handleChange={handleChange}/>
    </div>
  )
}

export default Sidebar